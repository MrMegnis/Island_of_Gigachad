# Island_of_Gigachad
Rouglike platformer game

Wonderful story about Gigachad Doctor Livesey that kills all of his enemies. This game was inspired by popular roguelike Dead Cells and Katana Zero. Hope you will enjoy.

The game is made in python using pygame library.

We made animations, levels, music, player and enemies, camera and more.

While we have been programmed this game we used object-oriented programming, so game contains a lot of classes, for example Player and Enemies, Animator and Level.

