import pygame
from gui.widgets.button import Button

class Dialog_Window:
    def __init__(self):
        pass